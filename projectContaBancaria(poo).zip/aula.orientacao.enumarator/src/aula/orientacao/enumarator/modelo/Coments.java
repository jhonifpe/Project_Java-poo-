package aula.orientacao.enumarator.modelo;

public class Coments {
	
// Para Depositar na conta (00)
	
		//ClientePersistencia cliente = new ClientePersistencia();
				
		//Cliente x = cliente.localizarClientePorCPF("222");
			
		//Conta xconta = x.localizarContaPorNumero("177B");
			
		//xconta.depositar(50);
			
		//x.atualizarConta(xconta);
			
		//cliente.atualizarCliente(x);
			
		//cliente.listarClientes();
// (00)	* 	
			
// para adicionar conta ao array do cliente (01)
			
		//ClientePersistencia cliente = new ClientePersistencia();   extra -> //c1.extrato(2023, Month.OCTOBER);
			
		//Cliente x = cliente.localizarClientePorCPF("111");
			
		//Conta newConta = new Conta("123B");
			
		//x.adicionarConta(newConta);
			
		//cliente.atualizarCliente(x);
			
		//cliente.listarClientes();
// (01) *
			
// Para Transferir quantia entre contas (02)
			
		//ClientePersistencia cliente = new ClientePersistencia();
			
		//Cliente cliente1 = cliente.localizarClientePorCPF("111");
			
		//Cliente cliente2 = cliente.localizarClientePorCPF("222");
			
		//Conta contaA = cliente1.localizarContaPorNumero("123B");
			
		//Conta contaB = cliente2.localizarContaPorNumero("177B");
			
		//Conta.transferir(50, contaB, contaA);
			
		//cliente1.atualizarConta(contaA);
			
		//cliente2.atualizarConta(contaB);
			
		//cliente.atualizarCliente(cliente1);
			
		//cliente.atualizarCliente(cliente2);
			
		//cliente.listarClientes();
// (02) *
	
// Para buscar Historico de Transações na conta [EXTRATO] (03)
	
		//ClientePersistencia cliente = new ClientePersistencia();
			
		//Cliente x = cliente.localizarClientePorCPF("222");
			
		//Conta c = x.localizarContaPorNumero("177B");
			
		//c.extrato(2023, Month.NOVEMBER);
// (03) *
	
// Para sacar valor (04)	
	
		//ClientePersistencia cliente = new ClientePersistencia();
			
		//Cliente x = cliente.localizarClientePorCPF("222");
			
		//Conta xconta = x.localizarContaPorNumero("177B");
			
		//xconta.sacar(20);
			
		//x.atualizarConta(xconta);
			
		//cliente.atualizarCliente(x);
			
		//cliente.listarClientes();
// (04) *
	
// Para consultar balanço da conta (05)
	
		//ClientePersistencia cliente = new ClientePersistencia();
			
		//Cliente x = cliente.localizarClientePorCPF("111");
			
		//x.ConsultarBalanco();
// (05) *
	
// Para consultar saldo de uma conta especifica (06)
	
		//ClientePersistencia cliente = new ClientePersistencia();
	
		//Cliente x = cliente.localizarClientePorCPF("111");
		
		//Conta xconta = x.localizarContaPorNumero("123A");
			
		//x.consultarSaldo(xconta);
// (06) *

}
