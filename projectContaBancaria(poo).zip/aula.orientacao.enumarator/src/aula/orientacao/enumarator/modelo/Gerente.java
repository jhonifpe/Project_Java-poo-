package aula.orientacao.enumarator.modelo;

public class Gerente {
	
	public static boolean conferirCod(int cod) {
		
		if(cod == 1717)
			return true;
		else 
			return false;
	}

}
