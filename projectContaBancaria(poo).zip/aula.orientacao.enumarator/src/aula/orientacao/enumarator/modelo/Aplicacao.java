package aula.orientacao.enumarator.modelo;

import java.time.Month;
import java.util.Scanner;

import aula.orientacao.enumarator.persistencia.ClientePersistencia;

public class Aplicacao {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
				
		int opcao;
		String num_conta;
		String numContaDestino;
		String cpf;
		String cpf_destino;
		String nome;
		float valor_saque;
		float valorDeposito;
		float valorTransf;
		int year;
		int mes;
		int cod;
		int loop = 0;
		
		ClientePersistencia cliente = new ClientePersistencia();
		
		//cliente.listarClientes();
	
//  /*
		while(loop <= 2) {
		System.out.println("Bem Vindo ao Caixa Eletrônico do IFPE \n");
		
		System.out.println("Escolha um numero para prosseguir:");
		System.out.println("__________________________________________________");
		System.out.println("Abrir conta -> Digite 1");
		System.out.println("Acessar sua conta -> Digite 2");
		System.out.println("Acessar informações das suas contas -> Digite 3");
		System.out.println("Acessar como Gerente do Banco: -> Digite 4");
		opcao = input.nextInt();
		
		if(opcao == 1) {
			
			System.out.println("Digite seu nome:");
			nome = input.next();
			
			System.out.println("Cadastre seu CPF:");
			cpf = input.next();
			
			System.out.println("\n");
			
			System.out.println("Digite um Numero para sua conta (EX: 123A):");
			num_conta = input.next();
			
			Cliente newclient = new Cliente(cpf,nome);
			
			Conta contaCliente = new Conta(num_conta);
			
			newclient.adicionarConta(contaCliente);
			
			cliente.salvarCliente(newclient);
		}
		
		if(opcao == 2) {
			
			int opcaoConta;
			
			System.out.println("[ Acesse sua Conta ]");
			
			System.out.println("Informe seu CPF:");
			cpf = input.next();
			
			System.out.println("Informe o Numero da sua conta:");
			num_conta = input.next();
			
			Cliente x = cliente.localizarClientePorCPF(cpf);
			
			if(x != null) {
				System.out.println("Bem Vindo a sua Conta Digital");
				System.out.println("| Acesse as funcões da sua conta | \n");
				System.out.println("Ver Informações da conta -> Digite 1");
				System.out.println("Consultar Saldo -> Digite 2");
				System.out.println("Realizar saque -> Digite 3");
				System.out.println("Realizar depósito -> Digite 4");
				System.out.println("Consultar Extrato -> Digite 5");
				System.out.println("Realizar Transferência -> Digite 6");
				opcaoConta = input.nextInt();
				
			switch (opcaoConta) {	
				case 1: 
					System.out.println(x.localizarContaPorNumero(num_conta));
					break;
					
				case 2:
					Conta contaSaldo = x.localizarContaPorNumero(num_conta);
					x.consultarSaldo(contaSaldo);
						
					if(contaSaldo == null) {
						contaSaldo = null;
					}
					
					break;
					
				case 3:
					
					System.out.println("Digite valor a ser Sacado:");
					valor_saque = input.nextFloat();
					
					Conta contaSaque = x.localizarContaPorNumero(num_conta);
					
					if(contaSaque != null) {
					contaSaque.sacar(valor_saque);
						
					x.atualizarConta(contaSaque);
						
					cliente.atualizarCliente(x);
					
					System.out.println("seu saque foi realizado no valor de: " + valor_saque);
					}
					
					if(contaSaque == null) {
						contaSaque = null;
					}
					
					break;
					
				case 4:
					
					System.out.println("Digite o valor a ser Depositado:");
					valorDeposito = input.nextFloat();
					
					Conta contaDep = x.localizarContaPorNumero(num_conta);
					
					if(contaDep != null) {
					contaDep.depositar(valorDeposito);
						
					x.atualizarConta(contaDep);
						
					cliente.atualizarCliente(x);
					
					System.out.println("Deposito realizado com sucesso! no valor de " + valorDeposito);
					}
					
					if(contaDep == null) {
						contaDep = null;
					}
					
					break;
					
				case 5:
					
					System.out.println("Digite o ano do Extrato que deseja:");
					year = input.nextInt();
					
					System.out.println("Digite apenas o N° do mes do Extrato que deseja:");
					mes = input.nextInt();
					
					Conta contaExtrato = x.localizarContaPorNumero(num_conta);
					
					if(mes == 1) 
						contaExtrato.extrato(year, Month.JANUARY);
					if(mes == 2)
						contaExtrato.extrato(year, Month.FEBRUARY);
					if(mes == 3)
						contaExtrato.extrato(year, Month.MARCH);
					if(mes == 4)
						contaExtrato.extrato(year, Month.APRIL);
					if(mes == 5)
						contaExtrato.extrato(year, Month.MAY);
					if(mes == 6)
						contaExtrato.extrato(year, Month.JUNE);
					if(mes == 7)
						contaExtrato.extrato(year, Month.JULY);
					if(mes == 8)
						contaExtrato.extrato(year, Month.AUGUST);
					if(mes == 9)
						contaExtrato.extrato(year, Month.SEPTEMBER);
					if(mes == 10)
						contaExtrato.extrato(year, Month.OCTOBER);
					if(mes == 11)
						contaExtrato.extrato(year, Month.NOVEMBER);
					if(mes == 12)
						contaExtrato.extrato(year, Month.DECEMBER);
					break;
					
				case 6:
					
					System.out.println("Digite valor a ser Transferido:");
					valorTransf = input.nextFloat();
					
					System.out.println("Digite o Numero da conta Destino para realizar a transferência:");
					numContaDestino = input.next();
					
					System.out.println("Digite o CPF do destinatario que voce deseja transferir:");
					cpf_destino = input.next();
					
					Cliente destinatario = cliente.localizarClientePorCPF(cpf_destino);
					
					Conta contaDestino = destinatario.localizarContaPorNumero(numContaDestino);
					
					Conta contaTitular = x.localizarContaPorNumero(num_conta);
					
				
					if(contaDestino != null) {
							
					contaTitular.transferir(valorTransf, contaDestino);
						
					x.atualizarConta(contaTitular);
						
					destinatario.atualizarConta(contaDestino);
						
					cliente.atualizarCliente(x);
						
					cliente.atualizarCliente(destinatario);
					
					System.out.println("Transferencia realizada com sucesso! no valor de: " + valorTransf + "R$");
					
					} else {
						destinatario = null;
						System.out.println("Conta de destinatário Não Econtrada!");
					}
				
					break;
					
				default:
					System.out.println("A opção escolhida não tem função");
				}
				
			} else {
				System.out.println("Ops!! esta Conta ou este CPF não foi encontrada no sistema");
			}
		}
		
		if(opcao == 3) {
			
			int opcaoDate;
			
			System.out.println("Digite seu cpf");
			cpf = input.next();
			
			System.out.println("Acessar todos seus dados e suas contas -> Digite 1");
			System.out.println("Adicionar uma nova conta -> Digite 2");
			System.out.println("Remover conta -> Digite 3");
			System.out.println("Consultar balanço das suas contas -> Digite 4");
			opcaoDate = input.nextInt();
			
			Cliente ex = cliente.localizarClientePorCPF(cpf);
			
			switch(opcaoDate) {
				
			case 1:
				if(ex != null) {
					System.out.println(ex);
				} else {
					System.out.println("cliente não encontrado");
				}
				
				break;
				
			case 2:
				
				if(ex != null) {
					
					System.out.println("Digite um numero para sua conta (EX: 125B):");
					num_conta = input.next();
				
					Conta nova = new Conta(num_conta);
				
					ex.adicionarConta(nova);
				
					cliente.atualizarCliente(ex);
				
				} else {
					System.out.println("cliente não encontrado");
				}
				
				break;
				
			case 3:
				
				if(ex != null) {
					
					System.out.println("Digite o numero da conta que voce deseja excluir:");
					num_conta = input.next();
					
					Conta contaExclused = ex.localizarContaPorNumero(num_conta);
					
					
					if(contaExclused.status && contaExclused.saldo <= 0) {
						ex.removerConta(contaExclused);
						
						cliente.atualizarCliente(ex);
					} else {
						System.out.println("esta conta contem saldo ou não existe, verifique e faça todo o saque para poder excluir a mesma!");
					}
					
				} else {
					System.out.println("cliente não encontrado");
				}
				
				break;
				
			case 4:
				
				if(ex != null) {
					
					System.out.println("Balanço das suas Contas (saldo total disponivel de todas suas contas!!)");
					
					ex.ConsultarBalanco();
				}
				
				break;
				
			default:
				System.out.println("A opção escolhida não tem função");
			
			}
			
		}
		
		if(opcao == 4) {
				
			System.out.println("Digite o Código para ter acesso a Todas as Contas Cadastradas:");
			cod = input.nextInt();
			
			String msgWarning = "Código Incorreto!";
			
			if(Gerente.conferirCod(cod) == true) {
				cliente.listarClientes();
			} else {
				System.out.println(msgWarning);
			}
		}
		
		System.out.println("Para voltar a tela inicial digite 1, caso queira sair digite 3");
		loop = input.nextInt();
		
		}
		
		System.out.println("Saindo do sistema Bancario !! Obrigado e volte sempe :)");
//  */
	}
				
}
